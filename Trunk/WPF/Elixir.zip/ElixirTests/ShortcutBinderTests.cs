﻿#if !SILVERLIGHT
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Controls;
using System.Windows.Input;
using NUnit.Framework;
using Elixir;

namespace ElixirTests
{
    //[TestFixture]
    public class ShortcutBinderTests
    {
        /*
        [Test]
        public void When_shortcut_binder_is_created_then_adds_input_binding()
        {
            var element = new TextBox();
            var vm = new MockViewModelWithAction();
            var gesture = new KeyGesture(Key.S, ModifierKeys.Shift);
            var shortcut = new ShortcutBinder(element, p => vm.Action(), p=>vm.IsActionEnabled, gesture);
            element.InputBindings.AsQueryable().Cast<InputBinding>().Where(i => i.Gesture == gesture);
            //var inputBinding = element.InputBindings.
        }

        [Test]
        public void When_shortcut_binder_is_invoked_then_invokes_action_on_viewmodel()
        {
            
        }
         * */
        
    }
}
#endif