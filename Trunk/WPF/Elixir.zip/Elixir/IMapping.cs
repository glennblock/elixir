namespace Elixir
{
    public interface IMapping
    {
        object Key { get; }
        object Value { get; }
    }
}